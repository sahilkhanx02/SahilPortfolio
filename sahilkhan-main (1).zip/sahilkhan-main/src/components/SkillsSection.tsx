import { Code, Layout, Server, Wrench } from "lucide-react";
import { motion } from "framer-motion";

const categories = [
  { title: "Languages", icon: Code, skills: ["C", "C++", "Java", "Python", "JavaScript"] },
  { title: "Frontend", icon: Layout, skills: ["HTML", "CSS", "Tailwind CSS", "Bootstrap"] },
  { title: "Backend", icon: Server, skills: ["Node.js", "Express.js"] },
  { title: "Tools", icon: Wrench, skills: ["Git", "GitHub", "VS Code"] },
];

const cardVariant = {
  hidden: { opacity: 0, y: 40, scale: 0.95 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { delay: i * 0.12, duration: 0.5, ease: "easeOut" as const },
  }),
};

const SkillsSection = () => (
  <section id="skills" className="py-24 relative overflow-hidden">
    <div className="absolute top-0 right-1/4 w-72 h-72 bg-primary/5 rounded-full blur-3xl" />

    <div className="container mx-auto px-4 relative">
      <motion.div
        className="text-center mb-16"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.6 }}
      >
        <p className="section-subtitle">Skills</p>
        <h2 className="section-title">Technologies I Work With</h2>
      </motion.div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((cat, i) => (
          <motion.div
            key={cat.title}
            className="glass-card p-6 neon-border group hover:border-primary/60 transition-all duration-300 hover:-translate-y-2 relative overflow-hidden"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            custom={i}
            variants={cardVariant}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="relative">
              <div className="w-12 h-12 rounded-lg bg-primary/15 flex items-center justify-center mb-4 group-hover:bg-primary/25 group-hover:scale-110 transition-all duration-300">
                <cat.icon className="text-primary" size={22} />
              </div>
              <h3 className="font-semibold text-lg mb-4">{cat.title}</h3>
              <div className="flex flex-wrap gap-2">
                {cat.skills.map((s) => (
                  <span key={s} className="text-xs font-code bg-secondary/80 text-muted-foreground px-3 py-1.5 rounded-md hover:bg-primary/20 hover:text-primary transition-colors cursor-default">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default SkillsSection;
