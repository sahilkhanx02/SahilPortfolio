import { ExternalLink, Github } from "lucide-react";
import { motion } from "framer-motion";

const projects = [
  {
    title: "Grade Mate",
    description: "A project designed to help students manage and track their academic performance efficiently. Users can organize grades and monitor progress in a structured way.",
    features: ["Grade tracking", "Academic progress monitoring", "Structured student dashboard"],
    tech: ["JavaScript", "HTML", "CSS"],
  },
  {
    title: "Digital Store",
    description: "A full-stack web application developed using modern web technologies, featuring a responsive user interface and scalable server-side architecture.",
    features: ["Responsive UI", "Full-stack architecture", "Scalable processing"],
    tech: ["Node.js", "Express.js", "Tailwind CSS", "JavaScript"],
  },
];

const cardVariant = {
  hidden: { opacity: 0, y: 50, scale: 0.95 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { delay: i * 0.2, duration: 0.6, ease: "easeOut" as const },
  }),
};

const ProjectsSection = () => (
  <section id="projects" className="py-24 relative overflow-hidden">
    <div className="absolute bottom-1/3 left-0 w-80 h-80 bg-accent/5 rounded-full blur-3xl" />

    <div className="container mx-auto px-4 relative">
      <motion.div
        className="text-center mb-16"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.6 }}
      >
        <p className="section-subtitle">Projects</p>
        <h2 className="section-title">Things I've Built</h2>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {projects.map((p, i) => (
          <motion.div
            key={p.title}
            className="glass-card neon-border group hover:border-primary/60 transition-all duration-300 hover:-translate-y-2 overflow-hidden relative"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            custom={i}
            variants={cardVariant}
          >
            <div className="h-2 bg-gradient-to-r from-primary to-accent group-hover:h-3 transition-all duration-300" />
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="p-6 relative">
              <h3 className="text-xl font-bold mb-3 group-hover:gradient-text transition-all duration-300">{p.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-4">{p.description}</p>
              <div className="mb-4">
                {p.features.map((f) => (
                  <span key={f} className="inline-block text-xs text-accent mr-2 mb-1">✦ {f}</span>
                ))}
              </div>
              <div className="flex flex-wrap gap-2 mb-6">
                {p.tech.map((t) => (
                  <span key={t} className="text-xs font-code bg-secondary/80 text-muted-foreground px-2.5 py-1 rounded hover:bg-primary/20 hover:text-primary transition-colors">{t}</span>
                ))}
              </div>
              <div className="flex gap-3">
                <a href="#" className="inline-flex items-center gap-1.5 text-sm text-primary hover:text-accent transition-colors">
                  <Github size={16} /> View Code
                </a>
                <a href="#" className="inline-flex items-center gap-1.5 text-sm text-primary hover:text-accent transition-colors">
                  <ExternalLink size={16} /> Live Demo
                </a>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default ProjectsSection;
