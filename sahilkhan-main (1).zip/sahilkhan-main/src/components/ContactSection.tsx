import { useState } from "react";
import { Mail, Phone, MapPin, Github, Linkedin, Send, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import emailjs from "@emailjs/browser";
import { toast } from "sonner";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.15, duration: 0.6, ease: "easeOut" as const },
  }),
};

const ContactSection = () => {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sending, setSending] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    try {
      await emailjs.send(
        "service_n5x9geq",
        "template_rg9inf2",
        { from_name: form.name, from_email: form.email, message: form.message },
        "b8W-7hXlELV4AFeD0"
      );
      toast.success("Message sent successfully!");
      setForm({ name: "", email: "", message: "" });
    } catch {
      toast.error("Failed to send message. Please try again.");
    } finally {
      setSending(false);
    }
  };

  return (
    <section id="contact" className="py-24 relative overflow-hidden">
      <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative">
        <motion.div
          className="text-center mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          custom={0}
          variants={fadeUp}
        >
          <p className="section-subtitle">Contact</p>
          <h2 className="section-title">Let's Work Together</h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-10 max-w-4xl mx-auto">
          <motion.div
            className="space-y-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            custom={1}
            variants={fadeUp}
          >
            {[
              { icon: Mail, label: "Email", value: "sahilkhan010504@gmail.com", href: "mailto:sahilkhan010504@gmail.com" },
              { icon: Phone, label: "Phone", value: "9993729496" },
              { icon: MapPin, label: "Location", value: "Rewa, Madhya Pradesh, India" },
            ].map((item) => (
              <div key={item.label} className="glass-card p-4 neon-border flex gap-3 items-center group hover:-translate-y-1 transition-transform duration-300">
                <item.icon className="text-primary group-hover:scale-110 transition-transform" size={20} />
                <div>
                  <p className="text-xs text-muted-foreground">{item.label}</p>
                  {item.href ? (
                    <a href={item.href} className="text-sm hover:text-primary transition-colors">{item.value}</a>
                  ) : (
                    <span className="text-sm">{item.value}</span>
                  )}
                </div>
              </div>
            ))}
            <div className="flex gap-4 pt-2">
              <a href="https://github.com/sahilkhanx02" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-secondary/60 flex items-center justify-center hover:bg-primary/20 hover:scale-110 transition-all duration-300">
                <Github size={20} className="text-muted-foreground hover:text-primary" />
              </a>
              <a href="https://www.linkedin.com/in/sahilkhanx02" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-secondary/60 flex items-center justify-center hover:bg-primary/20 hover:scale-110 transition-all duration-300">
                <Linkedin size={20} className="text-muted-foreground hover:text-primary" />
              </a>
            </div>
          </motion.div>

          <motion.form
            onSubmit={handleSubmit}
            className="glass-card p-6 neon-border space-y-4 group"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            custom={2}
            variants={fadeUp}
          >
            <input
              type="text"
              placeholder="Your Name"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full bg-secondary/50 border border-border/50 rounded-lg px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 transition-colors"
            />
            <input
              type="email"
              placeholder="Your Email"
              required
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full bg-secondary/50 border border-border/50 rounded-lg px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 transition-colors"
            />
            <textarea
              placeholder="Your Message"
              required
              rows={4}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              className="w-full bg-secondary/50 border border-border/50 rounded-lg px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 transition-colors resize-none"
            />
            <button type="submit" disabled={sending} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3 rounded-lg transition-all duration-300 flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-primary/25 hover:-translate-y-0.5 disabled:opacity-60">
              {sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />} {sending ? "Sending..." : "Send Message"}
            </button>
          </motion.form>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
