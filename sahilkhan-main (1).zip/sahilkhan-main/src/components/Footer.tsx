import { Github, Linkedin } from "lucide-react";
import { motion } from "framer-motion";

const Footer = () => (
  <motion.footer
    className="border-t border-border/50 py-8"
    initial={{ opacity: 0 }}
    whileInView={{ opacity: 1 }}
    viewport={{ once: true }}
    transition={{ duration: 0.6 }}
  >
    <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
      <span className="font-code text-sm gradient-text">&lt;Sahil Khan /&gt;</span>
      <div className="flex gap-4">
        <a href="https://github.com/sahilkhanx02" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary hover:scale-110 transition-all duration-300">
          <Github size={18} />
        </a>
        <a href="https://www.linkedin.com/in/sahilkhanx02" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary hover:scale-110 transition-all duration-300">
          <Linkedin size={18} />
        </a>
      </div>
      <p className="text-xs text-muted-foreground">© 2025 Sahil Khan. All rights reserved.</p>
    </div>
  </motion.footer>
);

export default Footer;
