import { Layout, Server, Globe, Smartphone, Layers, Bug } from "lucide-react";
import { motion } from "framer-motion";

const items = [
  { icon: Layout, label: "Frontend Development" },
  { icon: Server, label: "Backend Development" },
  { icon: Globe, label: "API Integration" },
  { icon: Smartphone, label: "Responsive Web Design" },
  { icon: Layers, label: "Full Stack Development" },
  { icon: Bug, label: "Problem Solving & Debugging" },
];

const itemVariant = {
  hidden: { opacity: 0, x: -20 },
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: { delay: i * 0.1, duration: 0.4, ease: "easeOut" as const },
  }),
};

const ExperienceSection = () => (
  <section className="py-24 relative overflow-hidden">
    <div className="absolute top-1/2 right-0 w-72 h-72 bg-primary/5 rounded-full blur-3xl" />

    <div className="container mx-auto px-4 relative">
      <motion.div
        className="text-center mb-16"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.6 }}
      >
        <p className="section-subtitle">Experience</p>
        <h2 className="section-title">Learning & Development Journey</h2>
      </motion.div>

      <motion.div
        className="max-w-3xl mx-auto glass-card p-8 neon-border relative overflow-hidden group"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-60px" }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        <div className="relative">
          <p className="text-muted-foreground leading-relaxed mb-8">
            Through building applications like Grade Mate and Digital Store, I have gained practical experience across the full development stack.
          </p>
          <div className="grid sm:grid-cols-2 gap-4">
            {items.map((item, i) => (
              <motion.div
                key={item.label}
                className="flex items-center gap-3 p-3 rounded-lg bg-secondary/40 hover:bg-primary/10 hover:-translate-x-1 transition-all duration-300 group/item"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                custom={i}
                variants={itemVariant}
              >
                <item.icon size={18} className="text-primary shrink-0 group-hover/item:scale-110 transition-transform" />
                <span className="text-sm">{item.label}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  </section>
);

export default ExperienceSection;
