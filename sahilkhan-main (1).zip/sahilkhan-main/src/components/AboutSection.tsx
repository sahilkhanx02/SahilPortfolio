import { GraduationCap, Target } from "lucide-react";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.15, duration: 0.6, ease: "easeOut" as const },
  }),
};

const AboutSection = () => (
  <section id="about" className="py-24 relative overflow-hidden">
    {/* Background accent */}
    <div className="absolute top-1/2 -left-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
    <div className="absolute bottom-0 right-0 w-60 h-60 bg-accent/5 rounded-full blur-3xl" />

    <div className="container mx-auto px-4 relative">
      <motion.div
        className="text-center mb-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-80px" }}
        custom={0}
        variants={fadeUp}
      >
        <p className="section-subtitle">About Me</p>
        <h2 className="section-title">Designing Solutions, Not Just Code</h2>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          className="glass-card p-8 neon-border relative group"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          custom={1}
          variants={fadeUp}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <div className="relative">
            <p className="text-muted-foreground leading-relaxed mb-6">
              I am a Computer Science graduate with a strong interest in software development and modern technologies. I enjoy coding, building projects, and continuously improving my technical skills.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              My career goal is to become a successful software engineer and contribute to impactful technology solutions that make a difference.
            </p>
          </div>
        </motion.div>

        <div className="space-y-6">
          <motion.div
            className="glass-card p-6 neon-border flex gap-4 group hover:-translate-y-1 transition-transform duration-300"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            custom={2}
            variants={fadeUp}
          >
            <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center shrink-0 group-hover:bg-primary/30 transition-colors">
              <GraduationCap className="text-primary" size={24} />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-1">B.Tech in Computer Science</h3>
              <p className="text-muted-foreground text-sm">Jawaharlal Nehru College Of Technology, Rewa, M.P</p>
              <p className="text-muted-foreground text-sm">Rajiv Gandhi Proudyogiki Vishwavidyalaya University</p>
              <p className="text-primary text-sm font-code mt-1">Graduated: 2025</p>
            </div>
          </motion.div>

          <motion.div
            className="glass-card p-6 neon-border flex gap-4 group hover:-translate-y-1 transition-transform duration-300"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            custom={3}
            variants={fadeUp}
          >
            <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center shrink-0 group-hover:bg-accent/30 transition-colors">
              <Target className="text-accent" size={24} />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-1">Career Goal</h3>
              <p className="text-muted-foreground text-sm">Aspiring Software Engineer focused on building scalable, impactful applications using modern technologies.</p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  </section>
);

export default AboutSection;
