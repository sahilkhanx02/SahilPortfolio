import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowDown, Download, Github, Linkedin, Sparkles } from "lucide-react";

const titles = ["Software Developer", "CS Graduate", "Full Stack Enthusiast", "Problem Solver"];

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] as const },
});

const HeroSection = () => {
  const [titleIdx, setTitleIdx] = useState(0);
  const [charIdx, setCharIdx] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = titles[titleIdx];
    const timeout = deleting ? 40 : 80;
    if (!deleting && charIdx === current.length) {
      setTimeout(() => setDeleting(true), 1800);
      return;
    }
    if (deleting && charIdx === 0) {
      setDeleting(false);
      setTitleIdx((prev) => (prev + 1) % titles.length);
      return;
    }
    const timer = setTimeout(() => setCharIdx((prev) => prev + (deleting ? -1 : 1)), timeout);
    return () => clearTimeout(timer);
  }, [charIdx, deleting, titleIdx]);

  return (
    <section id="home" className="min-h-screen flex items-center relative overflow-hidden pt-20">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/8 rounded-full blur-[150px] animate-glow-pulse" />
        <div className="absolute top-1/4 right-1/3 w-[400px] h-[400px] bg-accent/6 rounded-full blur-[120px] animate-glow-pulse" style={{ animationDelay: "1.5s" }} />
        <div className="absolute bottom-1/4 left-1/4 w-[300px] h-[300px] bg-[hsl(260,80%,60%)]/5 rounded-full blur-[100px] animate-glow-pulse" style={{ animationDelay: "3s" }} />

        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: "linear-gradient(hsl(217 91% 60%) 1px, transparent 1px), linear-gradient(90deg, hsl(217 91% 60%) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }} />

        {/* Floating particles */}
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-primary/40 animate-particle"
            style={{
              left: `${15 + i * 15}%`,
              top: `${60 + (i % 3) * 10}%`,
              animationDelay: `${i * 0.7}s`,
              animationDuration: `${3 + i * 0.5}s`,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 grid lg:grid-cols-[1.1fr_0.9fr] gap-16 items-center relative z-10">
        {/* Left content */}
        <div className="order-2 lg:order-1">
          <motion.div {...fadeUp(0.1)}>
            <span className="hero-badge mb-6">
              <Sparkles size={14} />
              Available for opportunities
            </span>
          </motion.div>

          <motion.p {...fadeUp(0.2)} className="text-muted-foreground text-sm font-code mb-3">
            {"// Hello, I'm"}
          </motion.p>

          <motion.h1 {...fadeUp(0.3)} className="text-5xl md:text-7xl font-extrabold mb-3 leading-[1.1]">
            Sahil <span className="gradient-text">Khan</span>
          </motion.h1>

          <motion.div {...fadeUp(0.4)} className="flex items-center gap-2 mb-6 h-10">
            <span className="text-xl md:text-2xl font-code text-primary">
              {titles[titleIdx].slice(0, charIdx)}
            </span>
            <span className="w-0.5 h-7 bg-primary animate-pulse rounded-full" />
          </motion.div>

          <motion.p {...fadeUp(0.5)} className="text-muted-foreground leading-relaxed max-w-lg mb-8 text-base">
            Computer Science graduate passionate about software development and modern technologies. Building real-world projects and continuously improving technical skills to become a successful software engineer.
          </motion.p>

          <motion.div {...fadeUp(0.6)} className="flex gap-4 flex-wrap mb-10">
            <a href="#projects" className="hero-cta-primary">
              View Projects
              <ArrowDown size={16} className="animate-bounce" />
            </a>
            <a href="/SahilCV.pdf" download className="hero-cta-secondary">
              <Download size={16} />
              Download CV
            </a>
            <a href="#contact" className="hero-cta-secondary">
              Contact Me
            </a>
          </motion.div>

          {/* Social + Stats row */}
          <motion.div {...fadeUp(0.7)} className="flex items-center gap-6 flex-wrap">
            <div className="flex gap-3">
              <a href="https://github.com/sahilkhanx02" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-secondary/60 border border-border/50 flex items-center justify-center hover:bg-primary/20 hover:border-primary/40 transition-all duration-200">
                <Github size={18} className="text-muted-foreground" />
              </a>
              <a href="https://www.linkedin.com/in/sahilkhanx02" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-secondary/60 border border-border/50 flex items-center justify-center hover:bg-primary/20 hover:border-primary/40 transition-all duration-200">
                <Linkedin size={18} className="text-muted-foreground" />
              </a>
            </div>
            <div className="h-8 w-px bg-border/50" />
            <div className="flex gap-6">
              <div className="text-center">
                <div className="text-xl font-bold gradient-text">2+</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Projects</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold gradient-text">5+</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Technologies</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold gradient-text">2025</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Graduate</div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Right — profile image */}
        <motion.div
          className="order-1 lg:order-2 flex justify-center"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="relative">
            {/* Decorative orbit ring */}
            <div className="absolute inset-[-30px] rounded-full border border-dashed border-primary/15 animate-spin-slow" />
            <div className="absolute inset-[-60px] rounded-full border border-dashed border-accent/10 animate-spin-slow" style={{ animationDirection: "reverse", animationDuration: "30s" }} />

            {/* Orbiting dots */}
            <div className="absolute inset-[-30px] animate-spin-slow">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-primary shadow-lg shadow-primary/50" />
            </div>
            <div className="absolute inset-[-60px] animate-spin-slow" style={{ animationDirection: "reverse", animationDuration: "30s" }}>
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-accent shadow-lg shadow-accent/50" />
            </div>

            {/* Glow */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-accent/20 to-[hsl(260,80%,60%)]/20 rounded-full blur-[50px] scale-125 animate-glow-pulse" />

            {/* Profile image with gradient ring */}
            <div className="relative profile-ring animate-float">
              <img
                src="/profile.jpg"
                alt="Sahil Khan"
                className="w-64 h-64 md:w-80 md:h-80 rounded-full object-cover shadow-2xl"
                fetchPriority="high"
              />
            </div>

            {/* Floating badge */}
            <motion.div
              className="absolute -bottom-2 -right-2 glass-card px-4 py-2 rounded-xl border border-primary/30 shadow-lg"
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            >
              <span className="font-code text-xs text-primary">B.Tech CS</span>
            </motion.div>

            <motion.div
              className="absolute -top-2 -left-4 glass-card px-3 py-2 rounded-xl border border-accent/30 shadow-lg"
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            >
              <span className="font-code text-xs text-accent">{'</>'} Sahil</span>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
      >
        <span className="text-[10px] text-muted-foreground uppercase tracking-widest">Scroll</span>
        <div className="w-5 h-8 rounded-full border border-muted-foreground/30 flex items-start justify-center p-1">
          <motion.div
            className="w-1 h-2 rounded-full bg-primary"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;
